### Define your custom tool here. Check prebuilts in gentopia.tool (:###
from gentopia.tools import *
